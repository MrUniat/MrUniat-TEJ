/*==============================================================================
 Project: Lab 1
 
This lab allows us to explore the functionality of the UBMP specifically
looking at using the buttons as inputs and using the lights and buzzer as
outputs
==============================================================================*/

#include    "xc.h"              // Microchip XC8 compiler include file
#include    "stdint.h"          // Include integer definitions
#include    "stdbool.h"         // Include Boolean (true/false) definitions

#include    "UBMP420.h"         // Include UBMP4.2 constants and functions

//Initialize variables here!!!
int loop = 0;

// TODO Set linker ROM ranges to 'default,-0-7FF' under "Memory model" pull-down.
// TODO Set linker code offset to '800' under "Additional options" pull-down.

// The main function is required, and the program begins executing from here.

int main(void)
{

    // Configure oscillator and I/O ports. These functions run once at start-up.
    OSC_config();               // Configure internal oscillator for 48 MHz
    UBMP4_config();             // Configure on-board UBMP4 I/O devices
    
    // Code in this while loop runs repeatedly.
    while(1)
	{
            
        // The below code makes LED2 blink when swtich 2 (SW2) is pressed and 
        // makes a sound. Note how when switch 2 is pressed the signal goes to 
        // zero instead of one! 
        if(SW2 == 0)
        {
            LED2 = 1;
            __delay_ms(500);
            LED2 = 0;
            __delay_ms(500);

        while(loop < 1000) // this while loop cycles te speaker so it will make a note instad of just a click
            {
                BEEPER = 1;
                __delay_us(567);
                BEEPER = 0;
                __delay_us(567);
                loop = loop +1;
            }
        loop = 0;
        }

        // Activate bootloader if SW1 is pressed.
        if(SW1 == 0)
        {
            RESET();
        }
    }
}
